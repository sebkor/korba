package hunia.company;

import java.util.Scanner;

public class Main {



    public static void main(String[] args)
    {
        /*
        Punkt pk1 = new Punkt();
        Punkt pk2 = new Punkt(3,7);
        Punkt pk3 = new Punkt();
        pk3.setX(3);
        pk3.setY(8);
        pk2.opis();
        pk2.przesun();
        pk2.opis();
        Okrag ok1 = new Okrag();
        ok1.setPromien(5);
        ok1.opis();
        System.out.println(ok1.getPromien());
        System.out.println(ok1.getPowierzchnia());
        System.out.println(ok1.wSrodku(pk2));
         */
        Scanner scanner = new Scanner(System.in);
       // Samochod auto = new Samochod();
        SamochodOsobowy auto1 = new SamochodOsobowy(1,2,3);




        auto1.wyswietl();

















    }
}
